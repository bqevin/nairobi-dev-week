<?php
require_once 'core/init.php';
echo "Oops...that information can't be found ;)";

